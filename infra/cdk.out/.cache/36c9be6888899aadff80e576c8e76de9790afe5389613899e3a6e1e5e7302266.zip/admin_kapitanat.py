import json
import boto3
import os
from typing import Dict, Any
from datetime import datetime
from decimal import Decimal

class DecimalEncoder(json.JSONEncoder):
    """Custom JSON encoder that handles Decimal types from DynamoDB"""
    def default(self, obj):
        if isinstance(obj, Decimal):
            if float(obj).is_integer():
                return int(obj)
            else:
                return float(obj)
        return super(DecimalEncoder, self).default(obj)

def convert_decimals(obj):
    """Recursively convert Decimal objects to int/float in data structures"""
    if isinstance(obj, list):
        return [convert_decimals(item) for item in obj]
    elif isinstance(obj, dict):
        return {key: convert_decimals(value) for key, value in obj.items()}
    elif isinstance(obj, Decimal):
        if float(obj).is_integer():
            return int(obj)
        else:
            return float(obj)
    else:
        return obj

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb')
cognito = boto3.client('cognito-idp')

def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda function for admin kapitanat dashboard operations
    Handles: view submissions, manage team members, update cargo types
    """
    try:
        # Parse the request for HTTP API Gateway v2
        route_key = event.get('routeKey', '')
        raw_path = event.get('rawPath', '')
        path_parameters = event.get('pathParameters', {}) or {}
        http_method = route_key.split(' ')[0] if ' ' in route_key else 'GET'
        
        # Extract the path from pathParameters for proxy routes
        if 'proxy' in path_parameters:
            path = path_parameters['proxy']
        else:
            # Fallback: extract from route key
            path_parts = route_key.split(' ')
            if len(path_parts) >= 2:
                full_path = path_parts[1]
                path = full_path.split('/')[-1]  # Get last part of path
            else:
                path = ''
        
        body = json.loads(event.get('body', '{}')) if event.get('body') else {}
        query_params = event.get('queryStringParameters', {}) or {}
        
        # Verify admin authentication (check JWT token in Authorization header)
        auth_result = verify_admin_auth(event)
        if not auth_result['success']:
            return create_response(401, auth_result)
        
        # Route to appropriate handler
        if path == 'submissions':
            return handle_submissions(http_method, query_params, body)
        elif path == 'team-members':
            return handle_team_members(http_method, query_params, body)
        elif path == 'cargo-types':
            return handle_cargo_types(http_method, query_params, body)
        elif path == 'referral-sources':
            return handle_referral_sources(http_method, query_params, body)
        elif path == 'schemas':
            return handle_schemas(http_method, query_params, body)
        elif path == 'emails':
            return handle_emails(http_method, query_params, body)
        elif path == 'dashboard':
            return handle_dashboard(http_method, query_params)
        elif path == 'download-schema':
            return handle_download_schema(http_method, query_params, body)
        else:
            return create_response(404, {
                'success': False,
                'error': f'Endpoint not found: {path}'
            })
            
    except Exception as e:
        print(f"Error in admin kapitanat handler: {str(e)}")
        return create_response(500, {
            'success': False,
            'error': 'Internal server error'
        })

def verify_admin_auth(event: Dict[str, Any]) -> Dict[str, Any]:
    """Verify admin authentication via Cognito JWT token"""
    try:
        headers = event.get('headers', {})
        auth_header = headers.get('Authorization', '') or headers.get('authorization', '')
        
        if not auth_header or not auth_header.startswith('Bearer '):
            return {'success': False, 'error': 'Missing or invalid authorization header'}
        
        token = auth_header.replace('Bearer ', '')
        
        # DEVELOPMENT MODE: Allow mock tokens for testing
        if token.startswith('mock-jwt-token-'):
            print("🔧 Development mode: Accepting mock token")
            return {
                'success': True,
                'user': {
                    'username': 'dev-admin',
                    'email': 'dev@dock2gdansk.com',
                    'groups': ['admin']
                }
            }
        
        # PRODUCTION MODE: Verify with Cognito
        try:
            response = cognito.get_user(AccessToken=token)
            user_attributes = {attr['Name']: attr['Value'] for attr in response['UserAttributes']}
            
            # Check if user has admin role (you can customize this logic)
            # For now, we'll check if user is in admin group
            user_groups = cognito.admin_list_groups_for_user(
                UserPoolId=os.environ['USER_POOL_ID'],
                Username=response['Username']
            )
            
            is_admin = any(group['GroupName'] == 'admin' for group in user_groups['Groups'])
            
            if not is_admin:
                return {'success': False, 'error': 'Insufficient privileges'}
            
            return {
                'success': True,
                'user': {
                    'username': response['Username'],
                    'email': user_attributes.get('email'),
                    'groups': [group['GroupName'] for group in user_groups['Groups']]
                }
            }
        except Exception as cognito_error:
            print(f"Cognito verification error: {str(cognito_error)}")
            return {'success': False, 'error': 'Invalid Cognito token'}
        
    except Exception as e:
        print(f"Auth verification error: {str(e)}")
        return {'success': False, 'error': 'Authentication failed'}

def handle_submissions(http_method: str, query_params: Dict, body: Dict) -> Dict[str, Any]:
    """Handle form submissions management"""
    submissions_table = dynamodb.Table(os.environ['DYNAMODB_TABLE'])
    
    if http_method == 'GET':
        # List submissions with pagination
        limit = int(query_params.get('limit', '50'))
        last_key = query_params.get('lastKey')
        
        scan_kwargs = {'Limit': limit}
        if last_key:
            scan_kwargs['ExclusiveStartKey'] = json.loads(last_key)
        
        response = submissions_table.scan(**scan_kwargs)
        
        return create_response(200, {
            'success': True,
            'submissions': response['Items'],
            'lastKey': response.get('LastEvaluatedKey'),
            'count': response['Count']
        })
    
    elif http_method == 'DELETE':
        # Delete submission
        submission_id = query_params.get('id')
        timestamp = query_params.get('timestamp')
        
        if not submission_id or not timestamp:
            return create_response(400, {
                'success': False,
                'error': 'Missing id or timestamp parameter'
            })
        
        submissions_table.delete_item(
            Key={'id': submission_id, 'timestamp': timestamp}
        )
        
        return create_response(200, {
            'success': True,
            'message': 'Submission deleted successfully'
        })
    
    else:
        return create_response(405, {'success': False, 'error': 'Method not allowed'})

def handle_team_members(http_method: str, query_params: Dict, body: Dict) -> Dict[str, Any]:
    """Handle team members management"""
    if http_method == 'GET':
        # List team members
        try:
            response = cognito.list_users(UserPoolId=os.environ['USER_POOL_ID'])
            users = []
            
            for user in response['Users']:
                user_groups = cognito.admin_list_groups_for_user(
                    UserPoolId=os.environ['USER_POOL_ID'],
                    Username=user['Username']
                )
                
                user_attributes = {attr['Name']: attr['Value'] for attr in user['Attributes']}
                
                users.append({
                    'username': user['Username'],
                    'email': user_attributes.get('email'),
                    'status': user['UserStatus'],
                    'enabled': user['Enabled'],
                    'groups': [group['GroupName'] for group in user_groups['Groups']],
                    'created': user['UserCreateDate'].isoformat(),
                    'lastModified': user['UserLastModifiedDate'].isoformat()
                })
            
            return create_response(200, {
                'success': True,
                'users': users
            })
            
        except Exception as e:
            return create_response(500, {
                'success': False,
                'error': f'Failed to list users: {str(e)}'
            })
    
    elif http_method == 'POST':
        # Add new team member
        email = body.get('email')
        temporary_password = body.get('temporaryPassword', 'TempPass123!')
        is_admin = body.get('isAdmin', False)
        
        if not email:
            return create_response(400, {
                'success': False,
                'error': 'Email is required'
            })
        
        try:
            # Create user
            response = cognito.admin_create_user(
                UserPoolId=os.environ['USER_POOL_ID'],
                Username=email,
                UserAttributes=[
                    {'Name': 'email', 'Value': email},
                    {'Name': 'email_verified', 'Value': 'true'}
                ],
                TemporaryPassword=temporary_password,
                MessageAction='SUPPRESS'  # Don't send email automatically
            )
            
            # Add to admin group if specified
            if is_admin:
                cognito.admin_add_user_to_group(
                    UserPoolId=os.environ['USER_POOL_ID'],
                    Username=email,
                    GroupName='admin'
                )
            
            return create_response(201, {
                'success': True,
                'message': 'User created successfully',
                'username': email,
                'temporaryPassword': temporary_password
            })
            
        except Exception as e:
            return create_response(500, {
                'success': False,
                'error': f'Failed to create user: {str(e)}'
            })
    
    elif http_method == 'DELETE':
        # Remove team member
        username = query_params.get('username')
        
        if not username:
            return create_response(400, {
                'success': False,
                'error': 'Username is required'
            })
        
        try:
            cognito.admin_delete_user(
                UserPoolId=os.environ['USER_POOL_ID'],
                Username=username
            )
            
            return create_response(200, {
                'success': True,
                'message': 'User deleted successfully'
            })
            
        except Exception as e:
            return create_response(500, {
                'success': False,
                'error': f'Failed to delete user: {str(e)}'
            })
    
    else:
        return create_response(405, {'success': False, 'error': 'Method not allowed'})

def handle_cargo_types(http_method: str, query_params: Dict, body: Dict) -> Dict[str, Any]:
    """Handle cargo types management"""
    schemas_table = dynamodb.Table(os.environ['SCHEMAS_TABLE'])
    
    if http_method == 'GET':
        # Get current cargo types
        response = schemas_table.get_item(
            Key={'formId': 'config', 'version': 'cargo-types'}
        )
        
        if 'Item' not in response:
            return create_response(404, {
                'success': False,
                'error': 'Cargo types configuration not found'
            })
        
        return create_response(200, {
            'success': True,
            'cargoTypes': response['Item']['schema']['cargoTypes']
        })
    
    elif http_method == 'POST':
        # Add new cargo type
        cargo_id = body.get('id')
        name = body.get('name')
        description = body.get('description', '')
        
        if not cargo_id or not name:
            return create_response(400, {
                'success': False,
                'error': 'Cargo type ID and name are required'
            })
        
        # Get current config
        response = schemas_table.get_item(
            Key={'formId': 'config', 'version': 'cargo-types'}
        )
        
        if 'Item' not in response:
            return create_response(404, {
                'success': False,
                'error': 'Cargo types configuration not found'
            })
        
        config = response['Item']
        cargo_types = config['schema']['cargoTypes']
        
        # Check if ID already exists
        if any(ct['id'] == cargo_id for ct in cargo_types):
            return create_response(400, {
                'success': False,
                'error': f'Cargo type with ID "{cargo_id}" already exists'
            })
        
        # Add new cargo type with custom ID and bilingual support
        new_cargo_type = {
            'id': cargo_id,
            'name': name,  # Can be string or {en: "...", zh: "..."}
            'description': description,
            'active': True
        }
        cargo_types.append(new_cargo_type)
        
        # Update config (keep nextId for backward compatibility but don't use it)
        config['schema']['cargoTypes'] = cargo_types
        config['schema']['lastUpdated'] = datetime.utcnow().isoformat()
        
        schemas_table.put_item(Item=config)
        
        return create_response(201, {
            'success': True,
            'message': 'Cargo type added successfully',
            'cargoType': new_cargo_type
        })
    
    elif http_method == 'PUT':
        # Update cargo type
        original_id = query_params.get('originalId') or body.get('originalId')
        new_id = body.get('id')
        name = body.get('name')
        description = body.get('description')
        active = body.get('active')
        
        # Use new_id as identifier if originalId not provided (for backward compatibility)
        search_id = original_id or new_id
        
        if not search_id:
            return create_response(400, {
                'success': False,
                'error': 'Cargo type ID is required'
            })
        
        # Get current config
        response = schemas_table.get_item(
            Key={'formId': 'config', 'version': 'cargo-types'}
        )
        
        if 'Item' not in response:
            return create_response(404, {
                'success': False,
                'error': 'Cargo types configuration not found'
            })
        
        config = response['Item']
        cargo_types = config['schema']['cargoTypes']
        
        # Find cargo type to update
        cargo_to_update = None
        for cargo_type in cargo_types:
            if cargo_type['id'] == search_id:
                cargo_to_update = cargo_type
                break
        
        if not cargo_to_update:
            return create_response(404, {
                'success': False,
                'error': 'Cargo type not found'
            })
        
        # If changing ID, check if new ID already exists (unless it's the same cargo type)
        if new_id and new_id != search_id:
            if any(ct['id'] == new_id for ct in cargo_types if ct is not cargo_to_update):
                return create_response(400, {
                    'success': False,
                    'error': f'Cargo type with ID "{new_id}" already exists'
                })
            cargo_to_update['id'] = new_id
        
        # Update other fields
        if name is not None:
            cargo_to_update['name'] = name
        if description is not None:
            cargo_to_update['description'] = description
        if active is not None:
            cargo_to_update['active'] = active
            
        # Update timestamp
        cargo_to_update['lastUpdated'] = datetime.utcnow().isoformat()
        
        # Update config
        config['schema']['cargoTypes'] = cargo_types
        config['schema']['lastUpdated'] = datetime.utcnow().isoformat()
        
        schemas_table.put_item(Item=config)
        
        return create_response(200, {
            'success': True,
            'message': 'Cargo type updated successfully',
            'cargoType': cargo_to_update
        })
    
    elif http_method == 'DELETE':
        # Delete cargo type
        cargo_id = body.get('id')
        
        if not cargo_id:
            return create_response(400, {
                'success': False,
                'error': 'Cargo type ID is required'
            })
        
        # Get current config
        response = schemas_table.get_item(
            Key={'formId': 'config', 'version': 'cargo-types'}
        )
        
        if 'Item' not in response:
            return create_response(404, {
                'success': False,
                'error': 'Cargo types configuration not found'
            })
        
        config = response['Item']
        cargo_types = config['schema']['cargoTypes']
        
        # Find and remove cargo type
        original_count = len(cargo_types)
        cargo_types = [ct for ct in cargo_types if ct['id'] != cargo_id]
        
        if len(cargo_types) == original_count:
            return create_response(404, {
                'success': False,
                'error': 'Cargo type not found'
            })
        
        # Update config
        config['schema']['cargoTypes'] = cargo_types
        config['schema']['lastUpdated'] = datetime.utcnow().isoformat()
        
        schemas_table.put_item(Item=config)
        
        return create_response(200, {
            'success': True,
            'message': 'Cargo type deleted successfully'
        })
    
    else:
        return create_response(405, {'success': False, 'error': 'Method not allowed'})

def handle_referral_sources(http_method: str, query_params: Dict, body: Dict) -> Dict[str, Any]:
    """Handle referral sources management"""
    schemas_table = dynamodb.Table(os.environ['SCHEMAS_TABLE'])
    
    if http_method == 'GET':
        # Get current referral sources
        response = schemas_table.get_item(
            Key={'formId': 'config', 'version': 'referral-sources'}
        )
        
        if 'Item' not in response:
            return create_response(404, {
                'success': False,
                'error': 'Referral sources configuration not found'
            })
        
        return create_response(200, {
            'success': True,
            'sources': response['Item']['schema']['referralSources']
        })
    
    elif http_method == 'POST':
        # Add new referral source
        source_id = body.get('id')
        name = body.get('name')
        description = body.get('description', '')
        
        if not source_id or not name:
            return create_response(400, {
                'success': False,
                'error': 'Source ID and name are required'
            })
        
        # Get current config
        response = schemas_table.get_item(
            Key={'formId': 'config', 'version': 'referral-sources'}
        )
        
        if 'Item' not in response:
            # Create initial config if it doesn't exist
            config = {
                'formId': 'config',
                'version': 'referral-sources',
                'schema': {
                    'referralSources': [],
                    'createdAt': datetime.utcnow().isoformat()
                }
            }
        else:
            config = response['Item']
        
        sources = config['schema']['referralSources']
        
        # Check if ID already exists
        if any(src['id'] == source_id for src in sources):
            return create_response(400, {
                'success': False,
                'error': f'Referral source with ID "{source_id}" already exists'
            })
        
        # Add new referral source with custom ID and bilingual support
        new_source = {
            'id': source_id,
            'name': name,  # Can be string or {en: "...", zh: "..."}
            'description': description,
            'active': True
        }
        sources.append(new_source)
        
        # Update config
        config['schema']['referralSources'] = sources
        config['schema']['lastUpdated'] = datetime.utcnow().isoformat()
        
        schemas_table.put_item(Item=config)
        
        return create_response(201, {
            'success': True,
            'message': 'Referral source added successfully',
            'source': new_source
        })
    
    elif http_method == 'PUT':
        # Update referral source
        original_id = query_params.get('originalId') or body.get('originalId')
        new_id = body.get('id')
        name = body.get('name')
        description = body.get('description')
        active = body.get('active')
        
        # Use new_id as identifier if originalId not provided (for backward compatibility)
        search_id = original_id or new_id
        
        if not search_id:
            return create_response(400, {
                'success': False,
                'error': 'Referral source ID is required'
            })
        
        # Get current config
        response = schemas_table.get_item(
            Key={'formId': 'config', 'version': 'referral-sources'}
        )
        
        if 'Item' not in response:
            return create_response(404, {
                'success': False,
                'error': 'Referral sources configuration not found'
            })
        
        config = response['Item']
        sources = config['schema']['referralSources']
        
        # Find source to update
        source_to_update = None
        for source in sources:
            if source['id'] == search_id:
                source_to_update = source
                break
        
        if not source_to_update:
            return create_response(404, {
                'success': False,
                'error': 'Referral source not found'
            })
        
        # If changing ID, check if new ID already exists (unless it's the same source)
        if new_id and new_id != search_id:
            if any(src['id'] == new_id for src in sources if src is not source_to_update):
                return create_response(400, {
                    'success': False,
                    'error': f'Referral source with ID "{new_id}" already exists'
                })
            source_to_update['id'] = new_id
        
        # Update other fields
        if name is not None:
            source_to_update['name'] = name
        if description is not None:
            source_to_update['description'] = description
        if active is not None:
            source_to_update['active'] = active
            
        # Update timestamp
        source_to_update['lastUpdated'] = datetime.utcnow().isoformat()
        
        # Update config
        config['schema']['referralSources'] = sources
        config['schema']['lastUpdated'] = datetime.utcnow().isoformat()
        
        schemas_table.put_item(Item=config)
        
        return create_response(200, {
            'success': True,
            'message': 'Referral source updated successfully',
            'source': source_to_update
        })
    
    elif http_method == 'DELETE':
        # Delete referral source
        source_id = body.get('id')
        
        if not source_id:
            return create_response(400, {
                'success': False,
                'error': 'Referral source ID is required'
            })
        
        # Get current config
        response = schemas_table.get_item(
            Key={'formId': 'config', 'version': 'referral-sources'}
        )
        
        if 'Item' not in response:
            return create_response(404, {
                'success': False,
                'error': 'Referral sources configuration not found'
            })
        
        config = response['Item']
        sources = config['schema']['referralSources']
        
        # Find and remove referral source
        original_count = len(sources)
        sources = [src for src in sources if src['id'] != source_id]
        
        if len(sources) == original_count:
            return create_response(404, {
                'success': False,
                'error': 'Referral source not found'
            })
        
        # Update config
        config['schema']['referralSources'] = sources
        config['schema']['lastUpdated'] = datetime.utcnow().isoformat()
        
        schemas_table.put_item(Item=config)
        
        return create_response(200, {
            'success': True,
            'message': 'Referral source deleted successfully'
        })
    
    else:
        return create_response(405, {'success': False, 'error': 'Method not allowed'})

def handle_schemas(http_method: str, query_params: Dict, body: Dict) -> Dict[str, Any]:
    """Handle schema management with versioning"""
    schemas_table = dynamodb.Table(os.environ['SCHEMAS_TABLE'])
    
    if http_method == 'GET':
        # List all schemas or get specific schema versions
        form_id = query_params.get('formId')
        
        if form_id:
            # Get all versions of a specific form
            response = schemas_table.query(
                KeyConditionExpression='formId = :formId',
                ExpressionAttributeValues={':formId': form_id},
                ScanIndexForward=False  # Latest first
            )
            return create_response(200, {
                'success': True,
                'formId': form_id,
                'versions': response['Items']
            })
        else:
            # Get all schemas (exclude config items)
            response = schemas_table.scan(
                FilterExpression='formId <> :config',
                ExpressionAttributeValues={':config': 'config'}
            )
            
            # Group by formId
            schemas_by_form = {}
            for item in response['Items']:
                form_id = item['formId']
                if form_id not in schemas_by_form:
                    schemas_by_form[form_id] = []
                schemas_by_form[form_id].append({
                    'version': item['version'],
                    'createdAt': item.get('createdAt'),
                    'isActive': item.get('isActive', True),
                    'description': item.get('description', '')
                })
            
            # Sort versions for each form
            for form_id in schemas_by_form:
                schemas_by_form[form_id].sort(key=lambda x: x['createdAt'], reverse=True)
            
            return create_response(200, {
                'success': True,
                'schemas': schemas_by_form
            })
    
    elif http_method == 'POST':
        # Create new schema version
        form_id = body.get('formId')
        schema_data = body.get('schema')
        description = body.get('description', '')
        base_version = body.get('baseVersion')  # Version to copy from
        
        if not form_id or not schema_data:
            return create_response(400, {
                'success': False,
                'error': 'formId and schema are required'
            })
        
        try:
            # Generate new version number
            if base_version:
                # If copying from existing version, increment patch version
                version_parts = base_version.split('.')
                if len(version_parts) == 3:
                    major, minor, patch = version_parts
                    new_version = f"{major}.{minor}.{int(patch) + 1}"
                else:
                    new_version = f"{base_version}.1"
            else:
                # Get latest version for this form and increment
                response = schemas_table.query(
                    KeyConditionExpression='formId = :formId',
                    ExpressionAttributeValues={':formId': form_id},
                    ScanIndexForward=False,
                    Limit=1
                )
                
                if response['Items']:
                    latest_version = response['Items'][0]['version']
                    version_parts = latest_version.split('.')
                    if len(version_parts) == 3:
                        major, minor, patch = version_parts
                        new_version = f"{major}.{int(minor) + 1}.0"
                    else:
                        new_version = "1.1.0"
                else:
                    new_version = "1.0.0"
            
            # Create new schema version
            schema_item = {
                'formId': form_id,
                'version': new_version,
                'schema': schema_data,
                'createdAt': datetime.utcnow().isoformat(),
                'isActive': True,
                'description': description or f'Version {new_version} created by admin'
            }
            
            schemas_table.put_item(Item=schema_item)
            
            return create_response(201, {
                'success': True,
                'message': 'Schema version created successfully',
                'formId': form_id,
                'version': new_version,
                'schema': schema_item
            })
            
        except Exception as e:
            return create_response(500, {
                'success': False,
                'error': f'Failed to create schema version: {str(e)}'
            })
    
    elif http_method == 'PUT':
        # Update existing schema (creates new version)
        form_id = body.get('formId')
        version = body.get('version')
        schema_data = body.get('schema')
        description = body.get('description')
        is_active = body.get('isActive')
        
        if not form_id or not version:
            return create_response(400, {
                'success': False,
                'error': 'formId and version are required'
            })
        
        try:
            # Get existing schema
            response = schemas_table.get_item(
                Key={'formId': form_id, 'version': version}
            )
            
            if 'Item' not in response:
                return create_response(404, {
                    'success': False,
                    'error': 'Schema version not found'
                })
            
            existing_schema = response['Item']
            
            # Update fields
            update_expression = "SET updatedAt = :updatedAt"
            expression_values = {':updatedAt': datetime.utcnow().isoformat()}
            
            if schema_data is not None:
                update_expression += ", schema = :schema"
                expression_values[':schema'] = schema_data
            
            if description is not None:
                update_expression += ", description = :description"
                expression_values[':description'] = description
            
            if is_active is not None:
                update_expression += ", isActive = :isActive"
                expression_values[':isActive'] = is_active
            
            schemas_table.update_item(
                Key={'formId': form_id, 'version': version},
                UpdateExpression=update_expression,
                ExpressionAttributeValues=expression_values
            )
            
            return create_response(200, {
                'success': True,
                'message': 'Schema updated successfully',
                'formId': form_id,
                'version': version
            })
            
        except Exception as e:
            return create_response(500, {
                'success': False,
                'error': f'Failed to update schema: {str(e)}'
            })
    
    elif http_method == 'DELETE':
        # Delete schema version (only if not the last active version)
        form_id = query_params.get('formId')
        version = query_params.get('version')
        
        if not form_id or not version:
            return create_response(400, {
                'success': False,
                'error': 'formId and version are required'
            })
        
        try:
            # Check if this is the last active version
            response = schemas_table.query(
                KeyConditionExpression='formId = :formId',
                FilterExpression='isActive = :active',
                ExpressionAttributeValues={':formId': form_id, ':active': True}
            )
            
            active_versions = response['Items']
            if len(active_versions) <= 1 and any(v['version'] == version for v in active_versions):
                return create_response(400, {
                    'success': False,
                    'error': 'Cannot delete the last active version of a schema'
                })
            
            # Delete the schema version
            schemas_table.delete_item(
                Key={'formId': form_id, 'version': version}
            )
            
            return create_response(200, {
                'success': True,
                'message': 'Schema version deleted successfully',
                'formId': form_id,
                'version': version
            })
            
        except Exception as e:
            return create_response(500, {
                'success': False,
                'error': f'Failed to delete schema version: {str(e)}'
            })
    
    else:
        return create_response(405, {'success': False, 'error': 'Method not allowed'})

def handle_dashboard(http_method: str, query_params: Dict) -> Dict[str, Any]:
    """Handle dashboard overview"""
    if http_method != 'GET':
        return create_response(405, {'success': False, 'error': 'Method not allowed'})
    
    try:
        # Get submissions count
        submissions_table = dynamodb.Table(os.environ['DYNAMODB_TABLE'])
        submissions_response = submissions_table.scan(Select='COUNT')
        submissions_count = submissions_response['Count']
        
        # Get recent submissions (last 10)
        recent_submissions = submissions_table.scan(Limit=10)['Items']
        recent_submissions.sort(key=lambda x: x['timestamp'], reverse=True)
        
        # Get schemas count
        schemas_table = dynamodb.Table(os.environ['SCHEMAS_TABLE'])
        schemas_response = schemas_table.scan(Select='COUNT')
        schemas_count = schemas_response['Count']
        
        # Get users count
        users_response = cognito.list_users(UserPoolId=os.environ['USER_POOL_ID'])
        users_count = len(users_response['Users'])
        
        return create_response(200, {
            'success': True,
            'dashboard': {
                'statistics': {
                    'totalSubmissions': submissions_count,
                    'totalSchemas': schemas_count,
                    'totalUsers': users_count
                },
                'recentSubmissions': recent_submissions[:5]  # Only return 5 most recent
            }
        })
        
    except Exception as e:
        return create_response(500, {
            'success': False,
            'error': f'Failed to load dashboard: {str(e)}'
        })

def handle_emails(http_method: str, query_params: Dict, body: Dict) -> Dict[str, Any]:
    """Handle analysis email recipients management"""
    schemas_table = dynamodb.Table(os.environ['SCHEMAS_TABLE'])
    
    if http_method == 'GET':
        # Get email recipients from schema storage
        try:
            response = schemas_table.get_item(
                Key={'formId': 'config', 'version': 'analysis-emails'}
            )
            
            if 'Item' in response:
                emails = response['Item'].get('emails', [])
                
                # Fix emails without IDs (add sequential IDs)
                needs_update = False
                for i, email in enumerate(emails):
                    if 'id' not in email:
                        email['id'] = str(i + 1)
                        needs_update = True
                        
                # Update storage if we added IDs
                if needs_update:
                    schemas_table.put_item(Item={
                        'formId': 'config',
                        'version': 'analysis-emails',
                        'emails': emails,
                        'updatedAt': datetime.utcnow().isoformat()
                    })
            else:
                # Return default emails if none configured
                emails = [
                    {
                        'id': '1',
                        'email': 'Marek.Machalski@portgdansk.pl',
                        'name': 'Marek Machalski',
                        'addedAt': datetime.utcnow().isoformat(),
                        'active': True
                    },
                    {
                        'id': '2',
                        'email': 'michal@dagodigital.com',
                        'name': 'Michal',
                        'addedAt': datetime.utcnow().isoformat(),
                        'active': True
                    }
                ]
                
                # Store default emails
                schemas_table.put_item(Item={
                    'formId': 'config',
                    'version': 'analysis-emails',
                    'emails': emails,
                    'createdAt': datetime.utcnow().isoformat(),
                    'updatedAt': datetime.utcnow().isoformat()
                })
            
            return create_response(200, {
                'success': True,
                'emails': emails
            })
            
        except Exception as e:
            return create_response(500, {
                'success': False,
                'error': f'Failed to get email recipients: {str(e)}'
            })
    
    elif http_method == 'POST':
        # Add new email recipient
        email = body.get('email', '').strip().lower()
        name = body.get('name', email.split('@')[0])
        active = body.get('active', True)
        
        if not email:
            return create_response(400, {
                'success': False,
                'error': 'Email address is required'
            })
        
        try:
            # Get existing emails
            response = schemas_table.get_item(
                Key={'formId': 'config', 'version': 'analysis-emails'}
            )
            
            emails = response.get('Item', {}).get('emails', [])
            
            # Check if email already exists
            if any(e['email'].lower() == email for e in emails):
                return create_response(400, {
                    'success': False,
                    'error': 'Email address already exists'
                })
            
            # Add new email
            new_email = {
                'id': str(len(emails) + 1),
                'email': email,
                'name': name,
                'addedAt': datetime.utcnow().isoformat(),
                'active': active
            }
            
            emails.append(new_email)
            
            # Update storage
            schemas_table.put_item(Item={
                'formId': 'config',
                'version': 'analysis-emails',
                'emails': emails,
                'updatedAt': datetime.utcnow().isoformat()
            })
            
            return create_response(200, {
                'success': True,
                'message': 'Email recipient added successfully',
                'email': new_email
            })
            
        except Exception as e:
            return create_response(500, {
                'success': False,
                'error': f'Failed to add email recipient: {str(e)}'
            })
    
    elif http_method == 'PUT':
        # Update email recipient status
        email_id = body.get('id')
        active = body.get('active')
        
        if not email_id:
            return create_response(400, {
                'success': False,
                'error': 'Email ID is required'
            })
        
        try:
            # Get existing emails
            response = schemas_table.get_item(
                Key={'formId': 'config', 'version': 'analysis-emails'}
            )
            
            emails = response.get('Item', {}).get('emails', [])
            
            # Find and update email
            updated = False
            for email in emails:
                if email['id'] == email_id:
                    if active is not None:
                        email['active'] = active
                    email['updatedAt'] = datetime.utcnow().isoformat()
                    updated = True
                    break
            
            if not updated:
                return create_response(404, {
                    'success': False,
                    'error': 'Email recipient not found'
                })
            
            # Update storage
            schemas_table.put_item(Item={
                'formId': 'config',
                'version': 'analysis-emails',
                'emails': emails,
                'updatedAt': datetime.utcnow().isoformat()
            })
            
            return create_response(200, {
                'success': True,
                'message': 'Email recipient updated successfully'
            })
            
        except Exception as e:
            return create_response(500, {
                'success': False,
                'error': f'Failed to update email recipient: {str(e)}'
            })
    
    elif http_method == 'DELETE':
        # Remove email recipient
        email_id = body.get('id')
        email_address = body.get('email')
        
        if not email_id and not email_address:
            return create_response(400, {
                'success': False,
                'error': 'Email ID or email address is required'
            })
        
        try:
            # Get existing emails
            response = schemas_table.get_item(
                Key={'formId': 'config', 'version': 'analysis-emails'}
            )
            
            emails = response.get('Item', {}).get('emails', [])
            
            # Remove email by ID or email address
            original_count = len(emails)
            if email_id:
                emails = [e for e in emails if e.get('id') != email_id]
            else:
                emails = [e for e in emails if e.get('email', '').lower() != email_address.lower()]
            
            if len(emails) == original_count:
                return create_response(404, {
                    'success': False,
                    'error': 'Email recipient not found'
                })
            
            # Update storage
            schemas_table.put_item(Item={
                'formId': 'config',
                'version': 'analysis-emails',
                'emails': emails,
                'updatedAt': datetime.utcnow().isoformat()
            })
            
            return create_response(200, {
                'success': True,
                'message': 'Email recipient removed successfully'
            })
            
        except Exception as e:
            return create_response(500, {
                'success': False,
                'error': f'Failed to remove email recipient: {str(e)}'
            })
    
    else:
        return create_response(405, {'success': False, 'error': 'Method not allowed'})

def get_next_schema_version() -> int:
    """
    Get next schema version number by incrementing counter
    Returns integer version (1, 2, 3, etc.)
    """
    try:
        schemas_table = dynamodb.Table(os.environ['SCHEMAS_TABLE'])
        
        # Get current schema version counter
        counter_key = {'formId': 'counter', 'version': 'schema_version'}
        
        try:
            response = schemas_table.get_item(Key=counter_key)
            if 'Item' in response:
                current_version = int(response['Item'].get('value', 0))
            else:
                # Initialize counter - check if we have existing schemas
                current_version = 0
                
        except Exception as e:
            print(f"Error reading schema version counter: {e}")
            current_version = 0
        
        # Increment for next version
        next_version = current_version + 1
        
        # Update counter
        schemas_table.put_item(
            Item={
                'formId': 'counter',
                'version': 'schema_version',
                'value': next_version,
                'updatedAt': datetime.utcnow().isoformat()
            }
        )
        
        print(f"Generated new schema version: {next_version}")
        return next_version
        
    except Exception as e:
        print(f"Error generating schema version: {e}")
        # Fallback to timestamp-based version
        return int(datetime.utcnow().timestamp())

def get_complete_current_schema() -> Dict:
    """
    Get the complete current schema including form fields, cargo types, and referral sources
    """
    try:
        schemas_table = dynamodb.Table(os.environ['SCHEMAS_TABLE'])
        
        # Get form fields from current schema
        form_response = schemas_table.get_item(
            Key={'formId': 'dock2gdansk-main', 'version': '1.0.0'}
        )
        form_schema = form_response.get('Item', {}).get('schema', {}) if 'Item' in form_response else {}
        
        # Get cargo types
        cargo_response = schemas_table.get_item(
            Key={'formId': 'config', 'version': 'cargo-types'}
        )
        cargo_types = cargo_response.get('Item', {}).get('schema', {}).get('cargoTypes', []) if 'Item' in cargo_response else []
        
        # Get referral sources  
        referral_response = schemas_table.get_item(
            Key={'formId': 'config', 'version': 'referral-sources'}
        )
        referral_sources = referral_response.get('Item', {}).get('schema', {}).get('referralSources', []) if 'Item' in referral_response else []
        
        # Combine into complete schema
        complete_schema = {
            'formFields': form_schema.get('fields', []),
            'title': form_schema.get('title', {}),
            'description': form_schema.get('description', {}),
            'submitButton': form_schema.get('submitButton', {}),
            'cargoTypes': cargo_types,
            'referralSources': referral_sources,
            'metadata': {
                'lastUpdated': datetime.utcnow().isoformat(),
                'components': ['formFields', 'cargoTypes', 'referralSources']
            }
        }
        
        return complete_schema
        
    except Exception as e:
        print(f"Error getting complete schema: {e}")
        return {}

def save_schema_version(change_type: str = "manual", changed_component: str = "", change_details: str = "") -> int:
    """
    Save complete schema version to DynamoDB with version history
    Returns the new version number
    """
    try:
        # Get next version number
        version = get_next_schema_version()
        
        # Get complete current schema
        complete_schema = get_complete_current_schema()
        
        if not complete_schema:
            raise Exception("Failed to get complete schema")
        
        schemas_table = dynamodb.Table(os.environ['SCHEMAS_TABLE'])
        
        # Add change metadata
        complete_schema['metadata'].update({
            'version': version,
            'changeType': change_type,
            'changedComponent': changed_component,
            'changeDetails': change_details,
            'createdAt': datetime.utcnow().isoformat()
        })
        
        # Save the versioned schema
        schema_record = {
            'formId': 'homepage-form',
            'version': str(version),
            'schema': complete_schema,
            'createdAt': datetime.utcnow().isoformat(),
            'changeType': change_type,
            'isActive': True
        }
        
        schemas_table.put_item(Item=schema_record)
        
        # Also update the legacy 1.0.0 version for backwards compatibility
        legacy_record = {
            'formId': 'dock2gdansk-main',
            'version': '1.0.0',
            'schema': {
                'fields': complete_schema['formFields'],
                'title': complete_schema['title'],
                'description': complete_schema['description'], 
                'submitButton': complete_schema['submitButton']
            },
            'updatedAt': datetime.utcnow().isoformat(),
            'currentVersion': version
        }
        
        schemas_table.put_item(Item=legacy_record)
        
        print(f"Saved complete schema version {version} successfully")
        print(f"Change: {change_type} - {changed_component} - {change_details}")
        return version
        
    except Exception as e:
        print(f"Error saving schema version: {e}")
        return 0

def handle_download_schema(http_method: str, query_params: Dict, body: Dict) -> Dict[str, Any]:
    """Handle schema download requests"""
    if http_method != 'GET':
        return create_response(405, {'success': False, 'error': 'Method not allowed'})
    
    try:
        # Get version parameter (optional - defaults to current)
        version = query_params.get('version', 'current')
        
        if version == 'current':
            # Get complete current schema
            complete_schema = get_complete_current_schema()
            
            if not complete_schema:
                return create_response(404, {
                    'success': False,
                    'error': 'Schema not found'
                })
            
            # Convert any Decimal objects to regular Python types
            complete_schema = convert_decimals(complete_schema)
            
            # Add metadata
            download_data = {
                'downloadedAt': datetime.utcnow().isoformat(),
                'schemaVersion': 'current',
                'actualVersion': complete_schema.get('metadata', {}).get('version', 'unknown'),
                'schema': complete_schema
            }
            
        else:
            # Get specific version
            try:
                schemas_table = dynamodb.Table(os.environ['SCHEMAS_TABLE'])
                response = schemas_table.get_item(
                    Key={'formId': 'homepage-form', 'version': str(version)}
                )
                
                if 'Item' not in response:
                    return create_response(404, {
                        'success': False,
                        'error': f'Schema version {version} not found'
                    })
                
                schema_data = convert_decimals(response['Item']['schema'])
                download_data = {
                    'downloadedAt': datetime.utcnow().isoformat(),
                    'schemaVersion': version,
                    'schema': schema_data
                }
                
            except Exception as e:
                return create_response(500, {
                    'success': False,
                    'error': f'Error retrieving schema version {version}: {str(e)}'
                })
        
        # Return with appropriate headers for download
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Content-Disposition': f'attachment; filename="d2g-schema-v{download_data["actualVersion"] if version == "current" else version}-{datetime.utcnow().strftime("%Y%m%d-%H%M%S")}.json"',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'GET,OPTIONS'
            },
            'body': json.dumps(download_data, indent=2, ensure_ascii=False, cls=DecimalEncoder)
        }
        
    except Exception as e:
        print(f"Error in handle_download_schema: {str(e)}")
        return create_response(500, {
            'success': False,
            'error': f'Failed to download schema: {str(e)}'
        })

def create_response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    """Helper function to create consistent API responses"""
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,Authorization',
            'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
        },
        'body': json.dumps(body, cls=DecimalEncoder)
    }
